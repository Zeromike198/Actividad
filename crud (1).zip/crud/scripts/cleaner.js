const { sequelize } = require("../db");
const { Article } = require(`../db/article`);
const { User } = require(`../db/user`);

/**
 * Truncate tables and close connection.
 */
const clean = async () => {
  await User.truncate();
  await Article.truncate();
  await sequelize.close();
};

clean();
