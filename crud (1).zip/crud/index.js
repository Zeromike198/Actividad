"use strict";

require(`dotenv`).config();
const express = require(`express`);

const { sequelize } = require(`./db`);

const { session } = require(`./middlewares/session`);
const { auth, admin } = require("./middlewares/auth");
const { error404, error } = require("./middlewares/fallbacks");

const { login, logout } = require("./paths/auth");
const { listUsers, getUser, createUser, updateUser, deleteUser } = require("./paths/users");
const { listArticles, getArticle, createArticle, updateArticle, deleteArticle } = require("./paths/articles");


// Server application data
const app = express();
const port = parseInt(process.env.PORT) || 3000;
const hostname = process.env.HOST || `localhost`;


// Middlewares
app.use(express.json());
app.use(session);


// Authentication paths
app.post(`/login`, login);
app.post(`/logout`, logout);

// Users paths
app.get(`/user`, auth, admin, listUsers);
app.get(`/user/:id`, auth, admin, getUser);
app.post(`/user`, auth, admin, createUser);
app.put(`/user/:id`, auth, admin, updateUser);
app.delete(`/user/:id`, auth, admin, deleteUser);

// Articles paths
app.get(`/article`, auth, listArticles);
app.get(`/article/:id`, auth, getArticle);
app.post(`/article`, auth, createArticle);
app.put(`/article/:id`, auth, updateArticle);
app.delete(`/article/:id`, auth, deleteArticle);

// Fallbacks
app.use(error404);
app.use(error);


// Synchronize database
sequelize.sync();

// Start server
app.listen(port, hostname, () => {
  console.log(`Application running at http://${hostname}:${port}`);
});
