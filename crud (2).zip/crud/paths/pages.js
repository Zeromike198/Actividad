"use strict";

const { User } = require(`../db/user`);

/**
 * Index page.
 *
 * @type {import("express").RequestHandler}
 */
exports.indexPage = async (req, res, next) => {
  res.render(`index`);
};

/**
 * Render the login page for not logged in users.
 *
 * Redirect to index for logged in users.
 *
 * @type {import("express").RequestHandler}
 */
exports.loginPage = async (req, res, next) => {
  // Check if the user is logged in
  const userId = req.session.userId;
  const user = await User.findByPk(userId);

  if (user) {
    return res.redirect(`/`);
  }

  // Render login page
  res.render(`login`);
};

/**
 * User page.
 *
 * @type {import("express").RequestHandler}
 */
 exports.userPage = async (req, res, next) => {
  res.render(`user`);
};

/**
 * Users page.
 *
 * @type {import("express").RequestHandler}
 */
exports.usersPage = async (req, res, next) => {
  res.render(`users`);
};

/**
 * Article page.
 *
 * @type {import("express").RequestHandler}
 */
exports.articlePage = async (req, res, next) => {
  res.render(`article`);
};

/**
 * Articles page.
 *
 * @type {import("express").RequestHandler}
 */
exports.articlesPage = async (req, res, next) => {
  res.render(`articles`);
};

/**
 * Error page.
 *
 * @type {import("express").RequestHandler}
 */
exports.errorPage = async (req, res, next) => {
  res.render(`error`, { code: req.query.code, message: req.query.message });
};
