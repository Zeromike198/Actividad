"use strict";

const { Article } = require(`../db/article`);

/**
 * List articles.
 *
 * @type {import("express").RequestHandler}
 */
exports.listArticles = async (req, res) => {
  try {
    // Get list of articles and returns it
    const articles = await Article.findAll();
    res.send(articles);
  }
  catch(err) {
    next({ code: 500, msg: err.message });
  }
};

/**
 * Get article.
 *
 * @type {import("express").RequestHandler}
 */
exports.getArticle = async (req, res, next) => {
  try {
    // Get and validate article
    const article = await Article.findByPk(req.params.id);

    if (article === null) {
      return next({ code: 404, msg: `article not found` });
    }

    // Return article
    res.send(article);
  }
  catch(err) {
    next({ code: 500, msg: err.message });
  }
};

/**
 * Create a new article.
 *
 * @type {import("express").RequestHandler}
 */
exports.createArticle = async (req, res, next) => {
  try {
    // Insert new article
    const article = await Article.create({
      name: req.body.name,
      price: req.body.price,
    });

    // Return inserted article
    res.send(article);
  }
  catch(err) {
    next({ code: 500, msg: err.message });
  }
};

/**
 * Update article.
 *
 * @type {import("express").RequestHandler}
 */
exports.updateArticle = async (req, res, next) => {
  try {
    // Get and validate article
    const article = await Article.findByPk(req.params.id);

    if (article === null) {
      return next({ code: 404, msg: `article not found` });
    }

    // Update article
    article.set(`name`, req.body.name);
    article.set(`price`, req.body.price);
    await article.save();

    // Return article
    res.send(article);
  }
  catch(err) {
    next({ code: 500, msg: err.message });
  }
};

/**
 * Delete article.
 *
 * @type {import("express").RequestHandler}
 */
exports.deleteArticle = async (req, res, next) => {
  try {
    // Validate article
    const article = await Article.findByPk(req.params.id);

    if (article === null) {
      return next({ code: 404, msg: `article not found` });
    }

    // Delete and return article
    article.destroy();
    res.send(article);
  }
  catch(err) {
    next({ code: 500, msg: err.message });
  }
};
