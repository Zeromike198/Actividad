"use strict";

const { DataTypes } = require(`sequelize`);
const { sequelize } = require(`.`);

const Article = sequelize.define(`Article`, {
  name: { type: DataTypes.STRING },
  price: { type: DataTypes.FLOAT }
});

exports.Article = Article;
